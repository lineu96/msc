# htmcglm

<!-- badges: start -->

<!-- badges: end -->

## Introduction

`htmcglm` performs hypothesis testing for multivariate covariance generalized linear models.

This package is part of the Masters dissertation of the first author.

## Installation

You can install the development version of htmcglm like so:

``` r
library(devtools)
install_github("lineu96/htmcglm")
library(htmcglm)
```
